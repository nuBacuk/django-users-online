#!/usr/bin/env python
from setuptools import setup


setup(
    name="django-users-online",
    version="0.1.3",
    description="Browse online users in Django",
    long_description=open('README').read(),
    url="http://github.com/minigun/django-user-online/",
    author="Ilya Khramtsov",
    author_email="khramtsov.ilya@gmail.com",
    license="BSD",
    packages=["django-users-online"],
    classifiers=[
        "Environment :: Web Environment",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.3",
        "Programming Language :: Python :: 3.4",
        "Programming Language :: Python :: 3.5",
        "Framework :: Django",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
    ],
    keywords=["django", "user", "online"],
)
