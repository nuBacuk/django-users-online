from django.conf.urls import url
from .views import usersonline


urlpatterns = [
	url(r'^$', usersonline),
]
